// ignore_for_file: unnecessary_null_comparison, avoid_print

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:web_duplicate_app/models/counter.dart';
import 'package:web_duplicate_app/models/project.dart';
import 'package:web_duplicate_app/services/user.dart';

class ProjectService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final UserService _userService = UserService();

  Future<void> inviteUser(String email, String projectID) async {
    final projectRef = _firestore.collection('projects').doc(projectID);

    await projectRef.update({
      'assignedTo': FieldValue.arrayUnion([email])
    });
  }

  Future<void> updateFrameCounter(String projectID, bool increment) async {
    await _firestore.collection('projects').doc(projectID).update({
      'counters.framesCount': FieldValue.increment(increment ? 1 : -1),
    });
  }

  Future<ProjectModel?> readProject(String projectID) async {
    final doc = await _firestore.collection('projects').doc(projectID).get();
    return doc.exists ? ProjectModel.fromJson(doc.data()!) : null;
  }

  Stream<ProjectModel?> readProjectsSnapshot() async* {
    final user = await _userService.getCurrentUser();

    final projectsSnapshot = _firestore
        .collection('projects')
        .where(
          'assignedTo',
          arrayContains:
              user.email == 'admin@programador123.com' ? null : user.email,
        )
        .snapshots();

    await for (final snapshot in projectsSnapshot) {
      final projects = snapshot.docs
          .map((doc) => ProjectModel.fromJson(doc.data()))
          .toList();
      for (final project in projects) {
        yield project;
      }
    }
  }

  Future<void> createProject(ProjectModel project) async {
    // Admin can create without invitations
    await _firestore
        .collection('projects')
        .doc(project.projectID)
        .set(project.toJson());
  }

  Future<void> deleteProject(String projectID) async {
    await _firestore.collection('projects').doc(projectID).delete();
  }

  Future<void> updateProject(String projectID, ProjectModel project) async {
    final updatedData = project
        .copyWith(
          projectID: null,
        )
        .toJson();

    await _firestore.collection('projects').doc(projectID).update(updatedData);
  }

  Future<void> exampleUsage() async {
    // Create a sample project
    final newProject = ProjectModel(
      projectID: 'project',
      projectName: 'Example Project',
      projectDescription: 'This is an example project for demonstration.',
      status: 'To Do',
      date: DateTime.now(),
      counters: CounterModel(
        framesCount: 4,
        time: '0:02',
        estTimeSpeak: '0:02',
        wordsCount: 10,
        characters: 100,
      ),
      assignedTo: ['admin@programador123.com', 'no-admin@programador123.com'],
    );

    // // Create the project
    await createProject(newProject);

    // Read the created project
    final readProjectx = await readProject(newProject.projectID);
    print('Read project: ${readProjectx!.toJson()}');

    // Update the project
    final updatedProject = readProjectx.copyWith(
      projectName: 'Updated Project Name',
    );
    await updateProject(newProject.projectID, updatedProject);

    // Read projects snapshot
    await for (final project in readProjectsSnapshot()) {
      print('Project from snapshot: ${project!.toJson()}');
    }

    // Delete the project
    // await deleteProject(newProject.projectID);
  }
}

//TODO: Hacer methods service para frames
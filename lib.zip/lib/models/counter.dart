class CounterModel {
  final String time;
  final String estTimeSpeak;
  final int wordsCount;
  final int characters;
  final int framesCount;

  CounterModel({
    required this.framesCount,
    required this.time,
    required this.estTimeSpeak,
    required this.wordsCount,
    required this.characters,
  });

  factory CounterModel.fromJson(Map<String, dynamic> json) {
    return CounterModel(
      framesCount: json['framesCount'] as int,
      time: json['time'] as String,
      estTimeSpeak: json['estTimeSpeak'] as String,
      wordsCount: json['wordsCount'] as int,
      characters: json['characters'] as int,
    );
  }

  Map<String, dynamic> toJson() => {
        "framesCount": framesCount,
        'time': time,
        'estTimeSpeak': estTimeSpeak,
        'wordsCount': wordsCount,
        'characters': characters,
      };
}

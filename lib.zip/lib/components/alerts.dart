// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:flutter_google_places_hoc081098/flutter_google_places_hoc081098.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_maps_webservice/geocoding.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'package:web_duplicate_app/components/custom_alertdialog.dart';
import 'package:web_duplicate_app/components/snackbarMessage.dart';
import 'package:web_duplicate_app/constants.dart';
import 'package:web_duplicate_app/models/frame.dart';
import 'package:web_duplicate_app/models/location.dart';
import 'package:web_duplicate_app/services/frame.dart';

class AlertsComponent {
  final FrameService frameService = FrameService();

  Future<dynamic> showLocationAlert({
    required FrameModel frameModel,
    required String projectID,
    required String frameID,
    required BuildContext context,
  }) async {
    final geocoding = GoogleMapsGeocoding(
      apiKey: googlePlacesApiKey,
      baseUrl: placesNoCorsApi,
    );

    ValueNotifier<LatLng?> pickedLocationNotifier =
        ValueNotifier<LatLng?>(null);

    ValueNotifier<String?> dateNotifier = ValueNotifier<String?>(null);

    if (frameModel.location?.date != null) {
      dateNotifier.value = frameModel.location!.date;
    }
    if (frameModel.location?.locationAddress != null) {
      String lat =
          frameModel.location!.locationAddress.toString().split(', ')[0];
      String long =
          frameModel.location!.locationAddress.toString().split(', ')[1];
      LatLng coordinates =
          LatLng(double.parse(lat.trim()), double.parse(long.trim()));

      pickedLocationNotifier.value = coordinates;
    }

    Future<void> launchGoogleMaps(double latitude, double longitude) async {
      snackbarMessage(
        message: 'Google Maps opened correctly',
        errorMessage: 'Could not open the map. Chat with support to fix this.',
        context: context,
        functionCode: () async {
          await launchUrlString(
            "https://www.google.com/maps/dir/?api=1&destination=$latitude,$longitude&travelmode=driving",
          );
        },
      );
    }

    return CustomAlertDialogComponent(
      dateNotifier: dateNotifier,
      title: 'Location',
      content: SingleChildScrollView(
        child: ListBody(
          children: <Widget>[
            ListTile(
              leading: const Icon(
                Icons.location_on,
                color: Colors.white,
              ),
              title: const Text(
                'Pick a location',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () async {
                final Prediction? p = await PlacesAutocomplete.show(
                  proxyBaseUrl: placesNoCorsApi,
                  context: context,
                  apiKey: googlePlacesApiKey,
                  onError: (error) {
                    snackbarMessage(
                      errorMessage: error.errorMessage ?? 'Unknown error',
                      context: context,
                    );
                  },
                  mode: Mode.overlay, // or Mode.fullscreen
                  language: 'us',
                );
                List<GeocodingResult> response =
                    (await geocoding.searchByAddress(p!.description!)).results;
                if (response.isNotEmpty) {
                  pickedLocationNotifier.value = LatLng(
                    response[0].geometry.location.lat,
                    response[0].geometry.location.lng,
                  );
                }
              },
            ),
            ValueListenableBuilder<LatLng?>(
                valueListenable: pickedLocationNotifier,
                builder: (context, pickedLocation, child) {
                  if (pickedLocation == null) {
                    return const SizedBox.shrink();
                  }
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: defaultPadding),
                      const Text(
                        'Click on map to open Google Maps Navigation',
                        style: TextStyle(color: Colors.white),
                      ),
                      const SizedBox(height: defaultPadding / 4),
                      SizedBox(
                        height: 200,
                        child: GoogleMap(
                          onLongPress: (argument) {
                            launchGoogleMaps(
                              pickedLocation.latitude,
                              pickedLocation.longitude,
                            );
                          },
                          onTap: (latValue) {
                            launchGoogleMaps(
                              pickedLocation.latitude,
                              pickedLocation.longitude,
                            );
                          },
                          initialCameraPosition: CameraPosition(
                            target: pickedLocation,
                            zoom: 14,
                          ),
                          onMapCreated: (GoogleMapController controller) {},
                          markers: {
                            Marker(
                              markerId: const MarkerId('pickedLocation'),
                              position: pickedLocation,
                            ),
                          },
                        ),
                      ),
                      const SizedBox(height: defaultPadding),
                    ],
                  );
                }),
          ],
        ),
      ),
      onSubmit: () async {
        if (pickedLocationNotifier.value == null) {
          snackbarMessage(
            errorMessage: 'Location is required',
            context: context,
          );
          return;
        }
        if (dateNotifier.value == null) {
          snackbarMessage(
            errorMessage: 'Date is required',
            context: context,
          );
          return;
        }

        // TODO: AppFlowyID Here
        await frameService.updateLocation(
          LocationModel(
            date: dateNotifier.value!,
            locationAddress:
                '${pickedLocationNotifier.value!.latitude}, ${pickedLocationNotifier.value!.longitude}',
            appflowyID: 'yourAppflowyID',
          ),
          projectID,
          frameID,
        );

        Navigator.of(context).pop();
        snackbarMessage(
          message: 'Location added correctly.',
          context: context,
        );
      },
    ).showAlertDialog(context);
  }
}

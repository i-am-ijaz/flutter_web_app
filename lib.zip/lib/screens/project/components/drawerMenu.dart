// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:web_duplicate_app/components/custom_button.dart';
import 'package:web_duplicate_app/constants.dart';

class DrawerMenu extends StatefulWidget {
  const DrawerMenu({
    super.key,
  });

  @override
  State<DrawerMenu> createState() => _DrawerMenuState();
}

class _DrawerMenuState extends State<DrawerMenu> {
  bool isExpanded = false;

  toggleExpansion() {
    isExpanded = !isExpanded;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          width: isExpanded ? 140 : 0,
          height: double.infinity,
          margin: EdgeInsets.only(right: isExpanded ? 15 : 25),
          decoration: BoxDecoration(
            color: colorDarKBlue,
            border: Border.all(color: colorLightBlue, width: 1),
          ),
          child: Visibility(
            visible: isExpanded,
            child: const Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                SizedBox(height: defaultPadding / 2),
                CustomDrawerButton(
                  icon: icEventNotes,
                  text: 'Projects',
                ),
                SizedBox(height: defaultPadding / 2),
              ],
            ),
          ),
        ),
        Positioned(
          top: MediaQuery.of(context).size.height * .4,
          left: isExpanded ? 130 : 0,
          child: CloseOpenDrawerButton(
            isExpanded: isExpanded,
            onPressed: () => toggleExpansion(),
          ),
        ),
      ],
    );
  }
}

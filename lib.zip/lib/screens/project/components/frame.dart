// ignore_for_file: use_build_context_synchronously

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:web_duplicate_app/components/alerts.dart';
import 'package:web_duplicate_app/components/custom_button.dart';
import 'package:web_duplicate_app/components/snackbarMessage.dart';
import 'package:web_duplicate_app/models/sceneInformation.dart';
import 'package:web_duplicate_app/screens/project/components/custom_checkbox.dart';
import 'package:web_duplicate_app/components/custom_dropdown.dart';
import 'package:web_duplicate_app/screens/project/components/frame_counter.dart';
import 'package:web_duplicate_app/components/text_widget.dart';
import 'package:web_duplicate_app/constants.dart';
import 'package:web_duplicate_app/models/frame.dart';
import 'package:web_duplicate_app/screens/project/components/scriptInfoExpansionPanel.dart';
import 'package:web_duplicate_app/services/frame.dart';
import 'package:web_duplicate_app/services/project.dart';

class FrameComponent extends StatefulWidget {
  final String projectID;
  final FrameModel frameModel;

  const FrameComponent({
    super.key,
    required this.projectID,
    required this.frameModel,
  });

  @override
  State<FrameComponent> createState() => _FrameComponentState();
}

class _FrameComponentState extends State<FrameComponent> {
  FirebaseAuth firebaseAuth = FirebaseAuth.instance;
  final AlertsComponent alertsComponent = AlertsComponent();
  final FrameService frameService = FrameService();
  final ProjectService projectService = ProjectService();

  Future<void> _showDeleteDialogWarning(BuildContext context) async {
    return showDialog(
      context: context,
      builder: (context) {
        return Scaffold(
          backgroundColor: Colors.transparent,
          body: AlertDialog(
            backgroundColor: colorDarKBlue,
            title: const Text(
              'Delete Warning',
              style: TextStyle(color: Colors.white),
            ),
            content: Container(
              constraints: const BoxConstraints(maxWidth: 400),
              child: const Text(
                'Are you sure you want to delete this frame and all its related data, including images, texts, and comments? Pressing "OK" will permanently remove everything. This action cannot be undone.',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text(
                  'Cancel',
                  style: TextStyle(color: Colors.white),
                ),
              ),
              TextButton(
                onPressed: () {
                  frameService.deleteFrame(
                    widget.projectID,
                    widget.frameModel.id,
                  );

                  Navigator.pop(context);
                  snackbarMessage(
                    message: 'Frame deleted successfully.',
                    context: context,
                  );
                },
                child: const Text(
                  'OK',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
            shape: RoundedRectangleBorder(
              side: const BorderSide(color: colorSkyBlue, width: 1),
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 527,
      child: Stack(
        children: [
          Container(
            margin: const EdgeInsets.symmetric(
              vertical: 16,
              horizontal: 8,
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              border: Border.all(
                color: colorLightBlue,
                width: 1,
              ),
            ),
            child: Column(
              children: [
                allAlertDialogs(context, widget.frameModel),
                sketchImagesSection(),
                sceneInformationDropdowns(),
                const ScriptInformationExpansionPanelComponent(),
              ],
            ),
          ),
          Positioned(
            left: 0,
            top: 5,
            child: Row(
              children: [
                FrameCounter(
                  count: widget.frameModel.storyOrder,
                  onChange: (String newValue) {
                    frameService.updateStoryOrder(
                      double.parse(newValue),
                      widget.projectID,
                      widget.frameModel.id,
                    );
                  },
                  isShotOrder: false,
                ),
                const SizedBox(width: 3),
                FrameCounter(
                  count: widget.frameModel.shotOrder,
                  onChange: (String newValue) {
                    frameService.updateShotOrder(
                      double.parse(newValue),
                      widget.projectID,
                      widget.frameModel.id,
                    );
                  },
                  isShotOrder: true,
                ),
                const SizedBox(width: 3),
                CustomCheckBox(
                  initialValue: widget.frameModel.completed!,
                  onChange: (newValue) {
                    frameService.isCompleted(
                      newValue,
                      widget.projectID,
                      widget.frameModel.id,
                    );
                  },
                ),
              ],
            ),
          ),
          if (firebaseAuth.currentUser!.email == 'admin@programador123.com')
            Positioned(
              top: 5,
              left: 505,
              child: InkWell(
                onTap: () {
                  _showDeleteDialogWarning(context);
                },
                child: Container(
                  height: 22,
                  width: 22,
                  decoration: BoxDecoration(
                    color: colorMediumBlue,
                    shape: BoxShape.circle,
                    border: Border.all(color: colorLightBlue),
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.delete_outline,
                      color: Colors.white,
                      size: 16,
                    ),
                  ),
                ),
              ),
            )
        ],
      ),
    );
  }

  Widget allAlertDialogs(BuildContext context, FrameModel frameModel) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Row(
            children: [
              const SizedBox(width: 10),
              CustomButton(
                onPressed: () => alertsComponent.showLocationAlert(
                  frameModel: frameModel,
                  projectID: widget.projectID,
                  frameID: widget.frameModel.id,
                  context: context,
                ),
                icon: icLocation,
                text: 'Location',
              ),
              const SizedBox(width: 10),
              CustomButton(
                  onPressed: () => AlertsComponent().showLocationAlert(
                        frameModel: frameModel,
                        projectID: widget.projectID,
                        frameID: widget.frameModel.id,
                        context: context,
                      ),
                  icon: icCheckList,
                  text: 'Checklist'),
              const SizedBox(width: 10),
              CustomButton(
                  onPressed: () => AlertsComponent().showLocationAlert(
                        frameModel: frameModel,
                        projectID: widget.projectID,
                        frameID: widget.frameModel.id,
                        context: context,
                      ),
                  icon: icDeadline,
                  text: 'Deadline'),
            ],
          ),
        ),
        Container(
          height: 50,
          width: 0.5,
          color: colorLightBlue,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Row(
            children: [
              CustomButton(
                  onPressed: () => AlertsComponent().showLocationAlert(
                        frameModel: frameModel,
                        projectID: widget.projectID,
                        frameID: widget.frameModel.id,
                        context: context,
                      ),
                  icon: icIdeas,
                  text: 'Ideas'),
              const SizedBox(width: 10),
              CustomButton(
                  onPressed: () => AlertsComponent().showLocationAlert(
                        frameModel: frameModel,
                        projectID: widget.projectID,
                        frameID: widget.frameModel.id,
                        context: context,
                      ),
                  icon: icObstacle,
                  text: 'Obstacles'),
            ],
          ),
        ),
      ],
    );
  }

  Widget sketchImagesSection() {
    return Container(
      height: 280,
      decoration: BoxDecoration(
        border: Border.all(color: colorLightBlue, width: 0.5),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(),
          const Align(
            alignment: Alignment.center,
            child: TextWidget(
              text: 'IMAGE HERE',
              fontSize: 36,
              fontWeight: FontWeight.w600,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    CustomDropDown(
                      hint: 'Sketch Type',
                      options: const {
                        "Category": {
                          "Sketched":
                              "Expected Price: 12.00 USD per 6 frames.\nDetails: Black and white, rough lines, simple design.",
                          "Detailed":
                              "Expected Price: 30.00 USD per 6 frames.\nDetails: Coloured (simple), shading, shadows.",
                          "Colored":
                              "Expected Price: 70.00 USD per 25 frames.\nDetails: Coloured, shading, shadows, highlights and tones."
                        },
                        "Category2": {
                          "Sketched":
                              "Expected Price: 12.00 USD per 6 frames.\nDetails: Black and white, rough lines, simple design.",
                          "Detailed":
                              "Expected Price: 30.00 USD per 6 frames.\nDetails: Coloured (simple), shading, shadows.",
                          "Colored":
                              "Expected Price: 70.00 USD per 25 frames.\nDetails: Coloured, shading, shadows, highlights and tones."
                        }
                      },
                      onChange: (selectedOption) {
                        frameService.updateSceneInformation(
                          widget.frameModel.sceneInformation!.copyWith(
                            sketchType: selectedOption,
                          ),
                          widget.projectID,
                          widget.frameModel.id,
                        );
                      },
                    ),
                    const SizedBox(width: defaultPadding / 2),
                    const ArrowButtons(icon: icLeftAndroidArrow),
                    const SizedBox(width: 5),
                    Container(
                      decoration: BoxDecoration(
                        color: colorMediumBlue,
                        border: Border.all(color: colorLightBlue),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      child: const TextWidget(
                        text: '1 of 3',
                        fontSize: 11,
                      ),
                    ),
                    const SizedBox(width: 5),
                    const ArrowButtons(icon: icRightAndroidArrow),
                  ],
                ),
                CustomButton(
                  onPressed: () {
                    snackbarMessage(
                      message:
                          'This feature will be implemented in future updates.',
                      context: context,
                    );
                  },
                  icon: icDoubleArrow,
                  text: 'Arrows',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget sceneInformationDropdowns() {
    return Container(
      height: 40,
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // CustomDropDown(
          //   hint: 'Aspect Ratio',
          //   options: const {
          //     "1:1":
          //         "Square format, often used in social media profile pictures.",
          //     "4:3":
          //         "Standard television format used in older TVs and computer monitors.",
          //     "16:9":
          //         "Widescreen format commonly used in modern TVs, monitors, and YouTube videos.",
          //     "21:9":
          //         "Ultra-wide format often found in cinematic films and gaming monitors.",
          //     "9:16":
          //         "Vertical format commonly used in portrait mode on smartphones.",
          //     "3:2": "Common aspect ratio in DSLR camera photography.",
          //     "2.35:1":
          //         "Cinematic widescreen format used in many feature films."
          //   },
          //   onChange: (selectedOption) {
          //     frameService.updateSceneInformation(
          //       widget.frameModel.sceneInformation!.copyWith(
          //         aspectRatio: selectedOption,
          //       ),
          //       widget.projectID,
          //       widget.frameModel.id,
          //     );
          //   },
          // ),
          // const SizedBox(width: 10),
          // CustomDropDown(
          //   hint: 'Type of Shot',
          //   options: const {
          //     "ECU":
          //         "Extreme Close-Up - Focuses on a single detail or part of a subject, such as an actor's eye or a small object.",
          //     "CU":
          //         "Close-Up - Frames a subject's face or an object closely, emphasizing its details and expressions.",
          //     "MCU":
          //         "Medium Close-Up - Frames a subject from the chest or shoulders up, capturing facial expressions and some background.",
          //     "MS":
          //         "Medium Shot - Shows a subject from the waist up, providing a sense of the character's actions and reactions.",
          //     "MLS":
          //         "Medium Long Shot - Includes the subject from head to toe, allowing viewers to see body language and surroundings.",
          //     "LS":
          //         "Long Shot - Shows the subject from a distance, revealing their entire body and the surrounding environment.",
          //     "ELS":
          //         "Extreme Long Shot - Captures a subject from a very long distance, emphasizing the overall context and setting.",
          //     "WS":
          //         "Wide Shot or Establishing Shot - Introduces a scene or location, providing a broad view of the surroundings.",
          //     "OTS":
          //         "Over-the-Shoulder Shot - Frames a subject from behind another character's shoulder, offering their perspective.",
          //     "POV":
          //         "Point of View Shot - Represents what a character is seeing from their perspective, often with a subjective view.",
          //     "CUT":
          //         "Cutaway Shot - Shows a brief shot of something other than the main action, often used for context or reactions.",
          //     "LA":
          //         "Low-Angle Shot - Captures the subject from a low viewpoint, making them appear more powerful or imposing.",
          //     "HA":
          //         "High-Angle Shot - Films the subject from a high viewpoint, often making them appear smaller or vulnerable."
          //   },
          //   onChange: (selectedOption) {
          //     frameService.updateSceneInformation(
          //       widget.frameModel.sceneInformation!.copyWith(
          //         typeOfShot: selectedOption,
          //       ),
          //       widget.projectID,
          //       widget.frameModel.id,
          //     );
          //   },
          // ),
          // const SizedBox(width: 10),
          // CustomDropDown(
          //   hint: 'Cam. Angle',
          //   options: {},
          //   onChange: (selectedOption) {
          //     frameService.updateSceneInformation(
          //       widget.frameModel.sceneInformation!.copyWith(
          //         typeOfShot: selectedOption,
          //       ),
          //       widget.projectID,
          //       widget.frameModel.id,
          //     );
          //   },
          // ),
          // SizedBox(width: 10),
          // CustomDropDown(
          //   hint: 'Cam. Movement',
          //   items: ['a'],
          // ),
        ],
      ),
    );
  }
}
